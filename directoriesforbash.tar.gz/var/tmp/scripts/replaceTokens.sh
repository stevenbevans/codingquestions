#!/bin/bash

INPUT_FILE=$1
PROPERTIES_FILE=$2
OUTPUT_FILE_PATH=$3
DIR_NAME="$(dirname $OUTPUT_FILE_PATH)" 

## Check if directory exist if not create it
if [ ! -d "$DIR_NAME" ]
then	
    mkdir -p "$DIR_NAME"
fi

cp "$INPUT_FILE" "$OUTPUT_FILE_PATH"

## Do the text substitutions
while IFS="=" read key vals; do 
    ## echo $key  $vals
    sed -i -e "s/\[\[$key\]\]/$vals/g" "$OUTPUT_FILE_PATH" 
    

done < "$PROPERTIES_FILE"

exit 0

